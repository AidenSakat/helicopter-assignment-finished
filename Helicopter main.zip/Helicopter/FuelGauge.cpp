// Declaration File for FuelGauge
//-------------------------------------------------------
#include "FuelGauge.h"
#include <iomanip>
#include <iostream>

FuelGauge::FuelGauge()
{
	Fuel = 100;
	SubtractFuel = 0;
}
//-------------------------------------------------------
// Function to subtract fuel from total fuel and displays it
//-------------------------------------------------------
int FuelGauge:: getcurrentfuel()
{
	return Fuel += SubtractFuel;
}
//-------------------------------------------------------
// Subtracts fuel depending on what user input is
//-------------------------------------------------------
void FuelGauge::setcurrentfuel(int newfuel)
{
	if (newfuel == 1)
	{
		newfuel = -1;
	}
	if (newfuel == 3)
	{
			newfuel = -3;
	}
	if (newfuel == 5)
	{
			newfuel = -5;
	}
	SubtractFuel = newfuel;
}
//-------------------------------------------------------
// Warns user when low on fuel and crashes when user runs out of fuel
//-------------------------------------------------------
void FuelGauge::checkfuel()
{
	if (Fuel <= 20)
	{
		std::cout << "You are low on fuel. Please land soon and fuel up or you will crash!!!" << std::endl;
	}
	if (Fuel <= 5)
	{
		std::cout << "\nGame over... you ran out of fuel so your helicopter plummeted and crashed ): \nbetter luck next time!" << std::endl;
		exit(0);
	}
}
//-------------------------------------------------------
// Refuels the plane and calculates how much Fuel it took to fill up
//-------------------------------------------------------
int FuelGauge::refuel(int newfuel)
{
	int totalfuel;
	totalfuel = newfuel - Fuel;
	std::cout << "It took " << totalfuel << " Gallons to fill up your tank\n";
	Fuel = 100;
	return Fuel;
}

