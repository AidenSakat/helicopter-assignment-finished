// Main File
//-------------------------------------------------------
#include <iostream>
#include <istream>
#include "helicopter.h"

using std::cout;
using std::endl;
using std::cin;

// Entry Point
int main()
{
	// Classes
	Helicopter heli;

	// Variables
	char user_input;
	int speedup = 0;
	int speedforward =0;

	// Tutorial text
	cout << "This program will let you fly a helicopter.\n\nEnter U to increase altitude\nEnter D to decrease altitude\nEnter F to move forward\n";
	cout << "Enter X to land the helicopter and fuel up if you would like\nEnter Q to quit the program\n\nWhere would you like to move first?: ";
	
	// While loop to repeat user input until user quits or crashes helicopter
	while (cin >> user_input)
	{
		// If user inputs U program adds user input to altitude
		if (user_input == 'u' || user_input == 'U')
		{
			heli.getupprompt();

			// Functions to increase altitude, keep the helicopter moving, waste fuel, and to check if fuel is low
			heli.callallupfunctions(speedup);

			// List of your current stats
			heli.statsforup();
		}

		// If user inputs D program subtracts 101 from altitude
		if (user_input == 'd' || user_input == 'D')
		{
			// List of your current stats
			heli.downStats();
		}

		// If user inputs F program adds user input to distance
		if (user_input == 'f' || user_input == 'F')
		{
			heli.getforwardprompt();
			
			// Functions to increase speed, waste fuel, and to check if fuel is low
			heli.callallforwardfunctions(speedforward);
			
			// List of your current stats
			heli.statsforforward();
		}

		// If user inputs X program lands the helicopter and asks user if they want to refuel and displays current distance
		if (user_input == 'x' || user_input == 'X')
		{
			// Lands helicopter and asks if user wants to refuel
			heli.landing();
		}

		// If user achieves an altitude of below 0, quits game, or runs out of fuel then helicopter will crash and report it
		if ( user_input == 'q' || user_input == 'Q')
		{
				heli.throttleFinalSpeed();
			exit(0);
		}

		// Prompt to make it looks neater than a blank space
		cout << "\nWhere to next?: ";
	}
	return 0;
}
