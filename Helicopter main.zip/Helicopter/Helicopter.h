// Declaration File for Helicopter class
//-------------------------------------------------------
#ifndef HELICOPTER_H
#define HELICOPTER_H


class Helicopter
{
private:
	int altitude;
	int distance;
	int total;
	int speedforward;
	int speedup;
public:
	Helicopter();

	int getupprompt();
	int getforwardprompt();

	int currentAltitude();
	int altitudeDown();
	void resetAltitude();

	int getaltitude();
	void setaltitude(int);

	void callallupfunctions(int);
	void callallforwardfunctions(int);

	void statsforup();
	void statsforforward();
	void downStats();

	void landing();

	void throttleFinalSpeed();


};
#endif