// Declaration File for FuelGauge class
//-------------------------------------------------------
#ifndef FUELGAUGE_H
#define FUELGAUGE_H
class FuelGauge
{
private:
	int Fuel;
	int SubtractFuel;
public:
	FuelGauge();
	int getcurrentfuel();
	void setcurrentfuel(int);
	void checkfuel();
	int refuel(int);
};

#endif