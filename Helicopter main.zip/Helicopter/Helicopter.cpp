// Definition File for Helicopter (This file is pretty big but most of it is comments)
//-------------------------------------------------------
#include "helicopter.h"
#include "FuelGauge.h"
#include "Speedometer.h"
#include "Throttle.h"
#include <iomanip>
#include <iostream>

//-------------------------------------------------------
// Class list
//-------------------------------------------------------
FuelGauge FuelGaug;
Helicopter heli;
Throttle Throttl;
Speedometer Speedomete;

Helicopter::Helicopter()
{
	altitude = 0;
	distance = 0;
	total = 0;
	speedforward = 0;
	speedup = 0;
}
//-------------------------------------------------------
// this function asks and recieves altitude prompt
//-------------------------------------------------------
int Helicopter::getupprompt()
{
	// Asks user how high they want to fly with 3 different options
	std::cout << "How high do you wish to fly?\nEnter 1 to consume 1 fuel and increase your altitude by 100\nEnter 3 to consume 3 fuel and increase your altitude by 200\nEnter 5 to consume 5 fuel and increase your altitude by 300\n Command : ";
	std::cin >> speedup;
	// If user inputs a number not in the prompt it will ask the question again
	if (speedup != 1 && speedup != 3 && speedup != 5)
	{
		std::cout << "Please enter a valid prompt 1 , 3 , 5 \ncommand: ";
		std::cin >> speedup;
	};

	return speedup;
}
//-------------------------------------------------------
// this function asks and recieves forward prompt
//-------------------------------------------------------
int Helicopter::getforwardprompt()
{
	// Asks user how far they want to fly with 3 different options
	std::cout << "How fast do you wish to fly?\nEnter 1 to consume 1 fuel and go 30mph\nEnter 3 to consume 3 fuel and go 65mph\nEnter 5 to consume 5 fuel and go 100mph\n Command: ";
	std::cin >> speedforward;
	// If user inputs a number not in the prompt it will ask the question again
	if (speedforward != 1 && speedforward != 3 && speedforward != 5)
	{
		std::cout << "Please enter a valid prompt 1 , 3 , 5 \ncommand: ";
		std::cin >> speedforward;
	};
	return speedforward;
}
//-------------------------------------------------------
// This function displays current altitude
//-------------------------------------------------------
int Helicopter:: currentAltitude() 
{
	return total; 
}
//-------------------------------------------------------
// this function lowers the altitude of the helicopter
//-------------------------------------------------------
int Helicopter::altitudeDown()
{
	return total -= 101; 
}
//-------------------------------------------------------
// function to reset altitude to 0
//-------------------------------------------------------
void Helicopter:: resetAltitude() 
{ 
	total = 0;
}

//-------------------------------------------------------
// New functions to get and set altitude
//-------------------------------------------------------
int Helicopter::getaltitude()
{
	return total += altitude;
}
// Adds altitude
void Helicopter::setaltitude(int newaltitude)
{
	 if (newaltitude == 1)
	{
		 newaltitude = 100;
	}
	if (newaltitude == 3)
	{
		newaltitude = 200;
	}
	if (newaltitude == 5)
	{
		newaltitude = 300;
	}

	altitude = newaltitude;
}
//-------------------------------------------------------
// Calls all "up" functions from other classes 
//-------------------------------------------------------
void Helicopter::callallupfunctions(int up)
{
	up = speedup;
	heli.setaltitude(speedup);
	Throttl.setcurrentspeed(speedforward);
	FuelGaug.setcurrentfuel(speedup);
	FuelGaug.checkfuel();
	Speedomete.setcurrentmph(speedforward);
}
//-------------------------------------------------------
// Calls all "forward" functions from other classes 
//-------------------------------------------------------
void Helicopter::callallforwardfunctions(int speed)
{
	speed = speedforward;
	Throttl.setcurrentspeed(speedforward);
	FuelGaug.setcurrentfuel(speedforward);
	FuelGaug.checkfuel();
	Speedomete.setcurrentmph(speedforward);
}
//-------------------------------------------------------
// Shows the information when going up
//-------------------------------------------------------
void Helicopter::statsforup()
{
	std::cout << "Current Speed (MPH): " << Speedomete.getcurrentmph() << std::endl;
	std::cout << "Current fuel (Gallons): " << FuelGaug.getcurrentfuel() << std::endl;
	std::cout << "Current altitude: " << heli.getaltitude() << std::endl;
	std::cout << "Current distance: " << Throttl.addspeeds() << std::endl;
}
//-------------------------------------------------------
// Shows the information when going forward
//-------------------------------------------------------
void Helicopter::statsforforward()
{
	std::cout << "Current Speed (MPH): " << Speedomete.getcurrentmph() << std::endl;
	std::cout << "Current fuel (Gallons): " << FuelGaug.getcurrentfuel() << std::endl;
	std::cout << "Current altitude: " << heli.currentAltitude() << std::endl;
	std::cout << "Current distance: " << Throttl.addspeeds() << std::endl;
}
//-------------------------------------------------------
// Shows the information when going down (There are three different functions to show information because the up one increases altitude and speed if user inputs speed first.
// the forward one displays the current altitude and increases speed and the down one subtracts the altitude)
//-------------------------------------------------------
void Helicopter::downStats()
{
	FuelGaug.checkfuel();
	std::cout << "Current Speed (MPH): " << Speedomete.getcurrentmph() << std::endl;
	std::cout << "Current fuel (Gallons): " << FuelGaug.getcurrentfuel() << std::endl;
	std::cout << "Current altitude: " << heli.altitudeDown() << std::endl;
	std::cout << "Current distance: " << Throttl.addspeeds() << std::endl;

	if (heli.currentAltitude() <= -4)
	{
		std::cout << "\nGame over you crashed because you landed way too hard... ):\nFinal Distance Flown: " << Throttl.finalspeed() << std::endl;
		exit(0);
	}
	if (heli.currentAltitude() <= 0)
	{
		std::cout << "\nWoah that was a bumpy landing..\nDistance Flown: " << Throttl.finalspeed() << "\nYou may continue flying!" << std::endl;
		heli.resetAltitude();
	}
}
//-------------------------------------------------------
// Function lands helicopter and asks user for refuel
//-------------------------------------------------------
void Helicopter::landing()
{
	char gas;
	int totalfuel;
	int newfuel;
		heli.resetAltitude();
		std::cout << "Congratulations you have safely landed!!!\nFinal Distance Flown: " << Throttl.finalspeed() << std::endl;
		std::cout << "Would you like to fill up your fuel tank to 100? (Y/N) : ";
		std::cin >> gas;
		if (gas == 'y' || gas == 'Y')
		{
			totalfuel = 100;
			newfuel = FuelGaug.refuel(totalfuel);
			std::cout << "You have succesfully fueled up to " << newfuel << " Gallons!\nYou may continue flying!" << std::endl;
		}
}
//-------------------------------------------------------
// Reports crash if user quits program
//-------------------------------------------------------
void Helicopter::throttleFinalSpeed()
{
	std::cout << "\nGame over you crashed because the pilot quit the game... ):\nFinal Distance Flown: " << Throttl.finalspeed() << std::endl;

}