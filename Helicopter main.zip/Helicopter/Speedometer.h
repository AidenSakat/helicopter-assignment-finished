// Declaration File for Speedometer class
//-------------------------------------------------------
#ifndef SPEEDOMETER_H
#define SPEEDOMETER_H

class Speedometer
{
private:
	int Speed;
public:
	Speedometer();
	void setcurrentmph(int );
	int getcurrentmph();
};
#endif

