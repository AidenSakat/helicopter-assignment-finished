// Definition File for Throttle
//-------------------------------------------------------
#include <iomanip>
#include <iostream>
#include "Throttle.h"
#include "helicopter.h"

Throttle::Throttle()
{
	currentspeed;
	total = 0;
}
//-------------------------------------------------------
// Displays final speed
//-------------------------------------------------------
int Throttle::finalspeed()
{
	return total;
}
//-------------------------------------------------------
// Keeps adding speed to total
//-------------------------------------------------------
int Throttle::addspeeds()
{
	return total +=	currentspeed;
}
//-------------------------------------------------------
// Sets current speed kind of like cruise control
//-------------------------------------------------------
void Throttle::setcurrentspeed(int speed)
{
	if (speed == 1)
	{
		speed = 30;
	}
	if (speed == 3)
	{
		speed = 65;
	}
	if (speed == 5)
	{
		speed = 100;
	}

	currentspeed = speed;
}

