// Definition File for Speedometer class
//-------------------------------------------------------
#include "Speedometer.h"
#include <iostream>

Speedometer :: Speedometer()
{
	int Speed = 0;
}
//-------------------------------------------------------
// This function gets the current speed of the helicopter
//-------------------------------------------------------
int Speedometer::getcurrentmph()
{
	return Speed;
}
//-------------------------------------------------------
// Sets the current mph from user prompt
//-------------------------------------------------------
void Speedometer::setcurrentmph(int mph)
{
	if (mph == 1)
	{
		mph = 30;
	}
	if (mph == 3)
	{
		mph = 65;
	}
	if (mph == 5)
	{
		mph = 100;
	}

	Speed = mph;
}

