// Declaration File for Throttle class
//-------------------------------------------------------
#ifndef THROTTLE_H
#define THROTTLE_H

class Throttle 
{
private:
	int currentspeed;
	int total;
public:
	Throttle();
	int finalspeed();
	int addspeeds();
	void setcurrentspeed(int);
};

#endif

